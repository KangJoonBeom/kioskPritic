/**
 * 
 */
/**
 * @author ghwna
 *
 */
module Kiosk {
}