package com.joon.kiosk.product;

import com.joon.pack.dis.Cw;

public class Disp {
	String x = "x";
	final static String DOT = "★";	
	final static int DOT_COUNT = 48;
	public static void line() {
		for(int i=0;i<DOT_COUNT;i=i+1) {
			Cw.w(DOT);
		}
		Cw.wn("");
	}
	
	public static void title() {
		line();
		Cw.wn("직원 : 어서오세요 주문은 키오스크에서 진행해주세요");
		line();
	}

}
