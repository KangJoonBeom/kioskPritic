package com.joon.kiosk.product;

import java.util.ArrayList;
import java.util.Scanner;

import com.joon.pack.dis.Cw;

public class Kiosk {
	ProcMenuDrink procMenuDrink = new ProcMenuDrink();

	public static Scanner sc = new Scanner(System.in);
	public static String cmd;

	void run() {
		KioskSpt.productLoad();
		Disp.title();
		xx: while (true) {
			System.out.print("메뉴를 선택 해주세요. [1.음료선택 / 2.디저트선택 / e.계산하기]:");
			cmd = sc.next();
			switch (cmd) {	
			case "1":
				ProcMenuDrink.drinkmenu(); 	//음료메뉴 while 문
				break;
			case "2":
				Dessert.deesrtmenu();	//디저트 메뉴 while문
				break;
			case "e":
				DeadLine.Line();	//마지막 while문 실행
				break xx;
			default : 
				Cw.wn("장난 치지 말아주세요");
				break;	
			}
		}
	}

}
