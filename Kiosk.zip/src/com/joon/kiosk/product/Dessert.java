// ctl+shfit+r 한방에 바꾸기
package com.joon.kiosk.product;

import com.joon.pack.dis.Cw;

public class Dessert {

	public static void deesrtmenu() {
		for (Product p : KioskSpt.bake) {
			Cw.wn("--------------------------");
			Cw.wn(p.name + "" + p.price + "원");
			Cw.wn("--------------------------");
		}
		loop_b: while (true) {

			Cw.wn("");
			Cw.wn("디저트가 선택되었습니다.");
			Cw.wn("[1. 케이크 2. 빵 3. 마카롱 4. 라면 x. 뒤로가기]");
			
			Kiosk.cmd = Kiosk.sc.next();
			switch (Kiosk.cmd) {
			case "1":
				Cw.wn("☆케이크가 선택 되었습니다.☆");
				Product a = new Product("케이크", 6000);
				KioskSpt.basket.add(new Order(KioskSpt.bake.get(0)));
				break;
			case "2":
				Cw.wn("☆빵이 선택 되었습니다.☆");
				Product b = new Product("빵", 4000);
				KioskSpt.basket.add(new Order(KioskSpt.bake.get(1)));
				break;
			case "3":
				Cw.wn("☆마카롱이 선택 되었습니다.☆");
				Product c = new Product("마카롱", 2500);
				KioskSpt.basket.add(new Order(KioskSpt.bake.get(2)));
				break;
			case "4":
				Cw.wn("☆라면이 선택 되었습니다.☆");
				Product d = new Product("라면", 5000);
				KioskSpt.basket.add(new Order(KioskSpt.bake.get(3)));
				break;
			case "x":
				break loop_b;
			}
		}
	}

}
