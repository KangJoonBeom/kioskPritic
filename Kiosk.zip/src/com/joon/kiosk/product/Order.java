package com.joon.kiosk.product;


public class Order {
	public Product selectedProduct;

	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}

}
